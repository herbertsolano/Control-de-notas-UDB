﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Panel_Registro_Materia_Alumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbox_a = new System.Windows.Forms.ComboBox();
            this.bbt_Ingresar = new System.Windows.Forms.Button();
            this.cbox_b = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox_c = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbox_d = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbox_e = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_nciclos = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(99, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 58);
            this.label1.TabIndex = 0;
            this.label1.Text = "Materia :";
            // 
            // cbox_a
            // 
            this.cbox_a.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_a.FormattingEnabled = true;
            this.cbox_a.Location = new System.Drawing.Point(281, 106);
            this.cbox_a.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_a.Name = "cbox_a";
            this.cbox_a.Size = new System.Drawing.Size(371, 37);
            this.cbox_a.TabIndex = 1;
            // 
            // bbt_Ingresar
            // 
            this.bbt_Ingresar.BackColor = System.Drawing.SystemColors.HighlightText;
            this.bbt_Ingresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbt_Ingresar.Location = new System.Drawing.Point(693, 397);
            this.bbt_Ingresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bbt_Ingresar.Name = "bbt_Ingresar";
            this.bbt_Ingresar.Size = new System.Drawing.Size(168, 58);
            this.bbt_Ingresar.TabIndex = 2;
            this.bbt_Ingresar.Text = "Ingresar";
            this.bbt_Ingresar.UseVisualStyleBackColor = false;
            this.bbt_Ingresar.Click += new System.EventHandler(this.bbt_Ingresar_Click);
            // 
            // cbox_b
            // 
            this.cbox_b.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_b.FormattingEnabled = true;
            this.cbox_b.Location = new System.Drawing.Point(281, 171);
            this.cbox_b.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_b.Name = "cbox_b";
            this.cbox_b.Size = new System.Drawing.Size(371, 37);
            this.cbox_b.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(99, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 58);
            this.label2.TabIndex = 3;
            this.label2.Text = "Materia :";
            // 
            // cbox_c
            // 
            this.cbox_c.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_c.FormattingEnabled = true;
            this.cbox_c.Location = new System.Drawing.Point(281, 241);
            this.cbox_c.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_c.Name = "cbox_c";
            this.cbox_c.Size = new System.Drawing.Size(371, 37);
            this.cbox_c.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(99, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(229, 58);
            this.label3.TabIndex = 5;
            this.label3.Text = "Materia :";
            // 
            // cbox_d
            // 
            this.cbox_d.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_d.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_d.FormattingEnabled = true;
            this.cbox_d.Location = new System.Drawing.Point(281, 324);
            this.cbox_d.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_d.Name = "cbox_d";
            this.cbox_d.Size = new System.Drawing.Size(371, 37);
            this.cbox_d.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(99, 324);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 58);
            this.label4.TabIndex = 7;
            this.label4.Text = "Materia :";
            // 
            // cbox_e
            // 
            this.cbox_e.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_e.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_e.FormattingEnabled = true;
            this.cbox_e.Location = new System.Drawing.Point(281, 400);
            this.cbox_e.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_e.Name = "cbox_e";
            this.cbox_e.Size = new System.Drawing.Size(371, 37);
            this.cbox_e.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(99, 400);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(229, 58);
            this.label5.TabIndex = 9;
            this.label5.Text = "Materia :";
            // 
            // lbl_nciclos
            // 
            this.lbl_nciclos.AutoSize = true;
            this.lbl_nciclos.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nciclos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_nciclos.Location = new System.Drawing.Point(346, 19);
            this.lbl_nciclos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nciclos.Name = "lbl_nciclos";
            this.lbl_nciclos.Size = new System.Drawing.Size(169, 51);
            this.lbl_nciclos.TabIndex = 11;
            this.lbl_nciclos.Text = "CICLO 1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel1.Controls.Add(this.lbl_nciclos);
            this.panel1.Location = new System.Drawing.Point(5, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(878, 80);
            this.panel1.TabIndex = 12;
            // 
            // Admin_Panel_Registro_Materia_Alumno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(884, 496);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbox_e);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbox_d);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbox_c);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbox_b);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bbt_Ingresar);
            this.Controls.Add(this.cbox_a);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Admin_Panel_Registro_Materia_Alumno";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Panel_Registro_Materia_Alumno";
            this.Load += new System.EventHandler(this.Admin_Panel_Registro_Materia_Alumno_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbox_a;
        private System.Windows.Forms.Button bbt_Ingresar;
        private System.Windows.Forms.ComboBox cbox_b;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox_c;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbox_d;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbox_e;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_nciclos;
        private System.Windows.Forms.Panel panel1;
    }
}