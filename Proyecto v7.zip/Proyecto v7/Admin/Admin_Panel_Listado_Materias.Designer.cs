﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Panel_Listado_Materias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btt_Actualizar_Lista = new System.Windows.Forms.Button();
            this.btt_new_materia = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Dgrid_Materias = new System.Windows.Forms.DataGridView();
            this.btt_agregar_Materia = new System.Windows.Forms.Button();
            this.btt_lista_Materia = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Materias)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btt_Actualizar_Lista
            // 
            this.btt_Actualizar_Lista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Actualizar_Lista.Location = new System.Drawing.Point(1471, 254);
            this.btt_Actualizar_Lista.Margin = new System.Windows.Forms.Padding(4);
            this.btt_Actualizar_Lista.Name = "btt_Actualizar_Lista";
            this.btt_Actualizar_Lista.Size = new System.Drawing.Size(165, 98);
            this.btt_Actualizar_Lista.TabIndex = 118;
            this.btt_Actualizar_Lista.Text = "Actualizar lista";
            this.btt_Actualizar_Lista.UseVisualStyleBackColor = true;
            // 
            // btt_new_materia
            // 
            this.btt_new_materia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_new_materia.Location = new System.Drawing.Point(1471, 414);
            this.btt_new_materia.Margin = new System.Windows.Forms.Padding(4);
            this.btt_new_materia.Name = "btt_new_materia";
            this.btt_new_materia.Size = new System.Drawing.Size(165, 98);
            this.btt_new_materia.TabIndex = 115;
            this.btt_new_materia.Text = "Nuevo Materia";
            this.btt_new_materia.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(297, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(728, 69);
            this.label1.TabIndex = 119;
            this.label1.Text = "LISTADO DE MATERIAS";
            // 
            // Dgrid_Materias
            // 
            this.Dgrid_Materias.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgrid_Materias.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Dgrid_Materias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgrid_Materias.Location = new System.Drawing.Point(121, 207);
            this.Dgrid_Materias.Margin = new System.Windows.Forms.Padding(4);
            this.Dgrid_Materias.Name = "Dgrid_Materias";
            this.Dgrid_Materias.ReadOnly = true;
            this.Dgrid_Materias.RowHeadersWidth = 51;
            this.Dgrid_Materias.RowTemplate.Height = 24;
            this.Dgrid_Materias.Size = new System.Drawing.Size(995, 617);
            this.Dgrid_Materias.TabIndex = 114;
            // 
            // btt_agregar_Materia
            // 
            this.btt_agregar_Materia.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_agregar_Materia.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_agregar_Materia.Location = new System.Drawing.Point(1158, 339);
            this.btt_agregar_Materia.Margin = new System.Windows.Forms.Padding(4);
            this.btt_agregar_Materia.Name = "btt_agregar_Materia";
            this.btt_agregar_Materia.Size = new System.Drawing.Size(180, 89);
            this.btt_agregar_Materia.TabIndex = 117;
            this.btt_agregar_Materia.Text = "Agregar materia";
            this.btt_agregar_Materia.UseVisualStyleBackColor = false;
            this.btt_agregar_Materia.Click += new System.EventHandler(this.btt_agregar_Materia_Click);
            // 
            // btt_lista_Materia
            // 
            this.btt_lista_Materia.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_lista_Materia.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_lista_Materia.Location = new System.Drawing.Point(1158, 207);
            this.btt_lista_Materia.Margin = new System.Windows.Forms.Padding(4);
            this.btt_lista_Materia.Name = "btt_lista_Materia";
            this.btt_lista_Materia.Size = new System.Drawing.Size(180, 89);
            this.btt_lista_Materia.TabIndex = 116;
            this.btt_lista_Materia.Text = "Actualizar lista";
            this.btt_lista_Materia.UseVisualStyleBackColor = false;
            this.btt_lista_Materia.Click += new System.EventHandler(this.btt_lista_Materia_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1393, 146);
            this.panel1.TabIndex = 120;
            // 
            // Admin_Panel_Listado_Materias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(1388, 895);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btt_Actualizar_Lista);
            this.Controls.Add(this.btt_agregar_Materia);
            this.Controls.Add(this.btt_lista_Materia);
            this.Controls.Add(this.btt_new_materia);
            this.Controls.Add(this.Dgrid_Materias);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Admin_Panel_Listado_Materias";
            this.Text = "Admin_Panel_Listado_Materias";
            this.Load += new System.EventHandler(this.Admin_Panel_Listado_Materias_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Materias)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btt_Actualizar_Lista;
        private System.Windows.Forms.Button btt_new_materia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Dgrid_Materias;
        private System.Windows.Forms.Button btt_agregar_Materia;
        private System.Windows.Forms.Button btt_lista_Materia;
        private System.Windows.Forms.Panel panel1;
    }
}