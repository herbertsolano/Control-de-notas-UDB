﻿using Proyecto_V1.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1
{
    public partial class Form_Registro_Alumno : Form
    {
        static StreamReader leer_alumnos;
        public Form_Registro_Alumno()
        {
            InitializeComponent();
        }

        List<string> listado_alumnos = new List<string>();
        List<string> Contra_alumnos = new List<string>();

        private void Form_Registro_Alumno_Load(object sender, EventArgs e)
        {
            Revisar_Usuarios();
            Llenar();
        }
        //eliminar estudiante
        public void vaciar_Estudiante()
        {
            Dgrid_Estudiantes.Rows.Remove(Dgrid_Estudiantes.CurrentRow);
        }

        public void Revisar_Usuarios() 
        {
            
            listado_alumnos.Clear();
            Contra_alumnos.Clear();

            leer_alumnos = new StreamReader("User_Alumnos.txt");

            String element = "";

            while ((element = leer_alumnos.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = element.Split(delimitador);
                listado_alumnos.Add(components[0]);
                Contra_alumnos.Add(components[1]);
         
            }
            leer_alumnos.Close();


        }

        public void Llenar() 
        {

            StreamReader leer_alumnos = new StreamReader("User_Alumnos.txt");
            string[] columnnnames = leer_alumnos.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = leer_alumnos.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            leer_alumnos.Close();
            Dgrid_Estudiantes.DataSource = dt;
            Dgrid_Estudiantes.AutoResizeColumns();
        }

        private void btt_new_materia_Click(object sender, EventArgs e)
        {
            Admin_Ventana_Nuevo_Estudiante ir_nuevo_estudiante = new Admin_Ventana_Nuevo_Estudiante();
            ir_nuevo_estudiante.Show();
            Llenar();
        }

        private void Dgrid_Estudiantes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Llenar();
        }

        private void btt_Eliminar_Alumno_Click(object sender, EventArgs e)
        {
            vaciar_Estudiante();
        }

        private void btt_Modificar_Alumno_Click(object sender, EventArgs e)
        {
            Admin_Ventana_Modificar_Alumno Ventanita = new Admin_Ventana_Modificar_Alumno();
            Ventanita.Show();
        }
    }
}
