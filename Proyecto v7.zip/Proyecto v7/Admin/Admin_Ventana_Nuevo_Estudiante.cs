﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Ventana_Nuevo_Estudiante : Form
    {
        //Variable para poder escribir en archivos
        static StreamWriter Escribir;
        public Admin_Ventana_Nuevo_Estudiante()
        {
            InitializeComponent();
        }

        List<string> listado_alumnos = new List<string>();
        List<string> Contra_alumnos = new List<string>();


        private void btt_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_registrar_Click(object sender, EventArgs e)
        {
            

            //Procedemos a guardar los datos en un txt txtNombre.Text 
            if(txt_lname.Text != "" && txt_Nombre.Text !=""&&txt_Contraseña.Text!=""&&txt_Carnet.Text!="")
            {

                Registro_new_student.Carnet = txt_Carnet.Text;
                Registro_new_student.Nombre = txt_Nombre.Text;
                Registro_new_student.Apellido = txt_lname.Text;
                Registro_new_student.Correo = txt_email.Text;
                Registro.Nuevo_carnet = txt_Carnet.Text;
                string contraseña = txt_Contraseña.Text;
                string carrera = cbox_carreras.Text;

                Escribir = new StreamWriter("User_Alumnos.txt", true);
                Escribir.WriteLine(Registro_new_student.Carnet + "-" + contraseña + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-" + carrera);
                Escribir.Close();

                string f_name = "Estudiantes/"+txt_Carnet.Text + ".txt";

                StreamWriter writer = File.CreateText(f_name);
                writer.WriteLine("Materia-UV-Nota");
                writer.Close();

                Registro.n_ciclos = Convert.ToInt16(nup_Ciclos.Value);


                Admin_Panel_Registro_Materia_Alumno Ventanita = new Admin_Panel_Registro_Materia_Alumno();
                Ventanita.Show();

                //MessageBox.Show("Alumno y materias ingresadas correctamente");

                txt_Nombre.Clear();
                txt_lname.Clear();
                txt_email.Clear();
                txt_Carnet.Clear();
                txt_Contraseña.Clear();
                cbox_carreras.ResetText();

                this.Close();
            }
            else
            {
                MessageBox.Show("HAY ESPACIOS INCOMPLETOS");
            }

        }

    }
}
