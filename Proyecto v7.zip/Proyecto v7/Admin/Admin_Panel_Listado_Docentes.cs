﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Panel_Listado_Docentes : Form
    {
        static StreamReader leer_docentes;
        public Admin_Panel_Listado_Docentes()
        {
            InitializeComponent();
        }

        List<string> listado_docentes = new List<string>();
        List<string> Contra_docentes = new List<string>();

        public void Revisar_Usuarios()
        {

            listado_docentes.Clear();
            Contra_docentes.Clear();

            StreamReader leer_docentes = new StreamReader("User_Docentes.txt");

            String element = "";

            while ((element = leer_docentes.ReadLine()) != null)
            {
                char[] delimitador = { ' ' };
                string[] components = element.Split(delimitador);
                listado_docentes.Add(components[0]);
                Contra_docentes.Add(components[1]);
            }
            leer_docentes.Close();

        }
        public void Llenar()
        {

            leer_docentes = new StreamReader("User_Docentes.txt");
            string[] columnnnames = leer_docentes.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = leer_docentes.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            leer_docentes.Close();
            Dgrid_Docentes.DataSource = dt;
            Dgrid_Docentes.AutoResizeColumns();
        }
        //ELIMINAR DOCENTE.
        public void vaciar_docente()
        {
            Dgrid_Docentes.Rows.Remove(Dgrid_Docentes.CurrentRow);

        }


        private void btt_new_materia_Click(object sender, EventArgs e)
        {
            Admin_Ventana_Nuevo_Docente ir_nuevo_docente = new Admin_Ventana_Nuevo_Docente();
            ir_nuevo_docente.Show();
        }

        private void Admin_Panel_Listado_Docentes_Load(object sender, EventArgs e)
        {
            Llenar();
        }

        private void btt_actualizar_Click(object sender, EventArgs e)
        {
            Llenar();
        }

        private void btt_Eliminar_Docente_Click(object sender, EventArgs e)
        {
            vaciar_docente();
        }

        private void Dgrid_Docentes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
