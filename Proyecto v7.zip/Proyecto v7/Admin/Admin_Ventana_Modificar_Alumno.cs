﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Ventana_Modificar_Alumno : Form
    {
        int poc;
        public Admin_Ventana_Modificar_Alumno()
        {
            InitializeComponent();
        }
        public void Llenar()
        {
            //llenar valores desde el txt a la tabla
            StreamReader leer_alumnos = new StreamReader("User_Alumnos.txt");
            string[] columnnnames = leer_alumnos.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = leer_alumnos.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            leer_alumnos.Close();
            dgvModalum.DataSource = dt;
            dgvModalum.AutoResizeColumns();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            //actualizar en tabla
            string carnet, contraseña, apellido, nombre, correo, carrera;
            carnet = txt_Carnet.Text;
            contraseña = txt_Contraseña.Text;
            apellido = txt_lname.Text;
            nombre = txt_Nombre.Text;
            correo = txt_email.Text;
            carrera = cbox_carreras.SelectedItem.ToString();

            dgvModalum[0, poc].Value = carnet;
            dgvModalum[1, poc].Value = contraseña;
            dgvModalum[2, poc].Value = apellido;
            dgvModalum[3, poc].Value = nombre;
            dgvModalum[4, poc].Value = correo;
            dgvModalum[5, poc].Value = carrera;
            btnGuardar.Enabled = true;
            btnActualizar.Enabled = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //aqui se realiza la modificacion de txt
            using (var writetext = new StreamWriter("temp1.txt"))
            {
                foreach (DataGridViewRow row in dgvModalum.Rows)
                {
                    writetext.WriteLine($"{"Carnet"}-{"Contraseña"}-{"Apellido"}-{"Nombre"}-{"Correo"}-{"Carrera"}");
                    writetext.WriteLine($"{row.Cells[0].Value}-{row.Cells[1].Value}-{row.Cells[2].Value}-{row.Cells[3].Value}-{row.Cells[4].Value}-{row.Cells[5].Value}");
                }
            }
            File.Delete("User_Alumnos.txt");
            File.Move("temp1.txt", "User_Alumnos.txt");
            MessageBox.Show("Modificacion Realizada");
            btnGuardar.Enabled = false;
        }

        private void Admin_Ventana_Modificar_Alumno_Load(object sender, EventArgs e)
        {
            //usar el metodo llenar para ingresar los vzalores al grid
            Llenar();
            btnActualizar.Enabled = false;
            btnGuardar.Enabled = false;
        }

        private void dgvModalum_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //metodo para capturar los datos del grid y poder modificarse
            int v = 0;
            poc = dgvModalum.CurrentRow.Index;
            txt_Carnet.Text = Convert.ToString(dgvModalum[0, poc].Value);
            txt_Contraseña.Text = Convert.ToString(dgvModalum[1, poc].Value);
            txt_lname.Text = Convert.ToString(dgvModalum[2, poc].Value);
            txt_Nombre.Text = Convert.ToString(dgvModalum[3, poc].Value);
            txt_email.Text = Convert.ToString(dgvModalum[4, poc].Value);

            string name = Convert.ToString(cbox_carreras.Items[v]);
            string dname = Convert.ToString(dgvModalum[5, poc].Value);



            if (dname == "Lic. en Comunicaciones")
            {
                cbox_carreras.SelectedIndex = 0;

            }
            else if (dname == "Lic. en Diseño Grafico")
            {
                cbox_carreras.SelectedIndex = 1;
            }
            else if (dname == "Doctorado en Medicina")
            {
                cbox_carreras.SelectedIndex = 2;
            }
            else if (dname == "Arquitectura")
            {
                cbox_carreras.SelectedIndex = 3;
            }
            else if (dname == "Ing. Industrial")
            {
                cbox_carreras.SelectedIndex = 4;
            }
            else if (dname == "Ing. Electrica")
            {
                cbox_carreras.SelectedIndex = 5;
            }
            else
            {
                cbox_carreras.SelectedIndex = 6;
            }


            btnActualizar.Enabled = true;


            MessageBox.Show("Por favor actualize la tabla antes de guardar");
        }
    }
}
