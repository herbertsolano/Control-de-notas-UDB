﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Panel_Registro_Materia_Alumno : Form
    {
        static StreamWriter Escribir;
        int veces;
        List<string> Listado_Materia = new List<string>();

        public Admin_Panel_Registro_Materia_Alumno()
        {
            InitializeComponent();
            veces = 1;
        }

        private void Admin_Panel_Registro_Materia_Alumno_Load(object sender, EventArgs e)
        {
            
            StreamReader leer_materias = new StreamReader("Data_Materias.txt");

            String element = "";

            while ((element = leer_materias.ReadLine()) != null)
            {
                
                Listado_Materia.Add(element);
            }
            leer_materias.Close();

            foreach (string elemento in Listado_Materia)
            {
                if (elemento != "Materia-UV")
                {
                    cbox_a.Items.Add(elemento);
                    cbox_b.Items.Add(elemento);
                    cbox_c.Items.Add(elemento);
                    cbox_d.Items.Add(elemento);
                    cbox_e.Items.Add(elemento);
                }
            }

            cbox_a.SelectedIndex = 0;
            cbox_b.SelectedIndex = 0;
            cbox_c.SelectedIndex = 0;
            cbox_d.SelectedIndex = 0;
            cbox_e.SelectedIndex = 0;
        }

        private void bbt_Ingresar_Click(object sender, EventArgs e)
        {
            if (cbox_a.SelectedIndex == 0 && cbox_b.SelectedIndex == 0 && cbox_c.SelectedIndex == 0 && cbox_d.SelectedIndex == 0 && cbox_e.SelectedIndex == 0) 
            {
                MessageBox.Show("Ninguna materia seleccionada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Inscribir_materias();

            MessageBox.Show("Registro de ciclo " + veces + " correcto");


            

            if (veces == Registro.n_ciclos)
            {
                MessageBox.Show("Registro de alumno y materias correcto");
                Admin_Ventana_Nuevo_Estudiante Ventanita = new Admin_Ventana_Nuevo_Estudiante();
                Ventanita.Show();
                this.Close();
            }
            cbox_a.SelectedIndex = 0;
            cbox_b.SelectedIndex = 0;
            cbox_c.SelectedIndex = 0;
            cbox_d.SelectedIndex = 0;
            cbox_e.SelectedIndex = 0;
            veces += 1;
            lbl_nciclos.Text = "Ciclo " + (veces);
        }

        public void Inscribir_materias() 
        {
            string f_name = "Estudiantes/" + Registro.Nuevo_carnet + ".txt";
            Escribir = new StreamWriter(f_name, true);
            Escribir.WriteLine("Ciclo-" + veces+"- ");
            if (cbox_a.SelectedIndex != 0)
            {
                Escribir.WriteLine(cbox_a.Text+"-#");

                String materia = "Materias/" + cbox_a.Text + ".txt";
                StreamWriter Inscripcion = new StreamWriter(materia, true);
                Inscripcion.WriteLine(Registro_new_student.Carnet + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-#");
                Inscripcion.Close();
            }
            if (cbox_b.SelectedIndex != 0)
            {
                Escribir.WriteLine(cbox_b.Text + "-#");

                String materia = "Materias/" + cbox_b.Text + ".txt";
                StreamWriter Inscripcion = new StreamWriter(materia, true);
                Inscripcion.WriteLine(Registro_new_student.Carnet + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-#");
                Inscripcion.Close();
            }
            if (cbox_c.SelectedIndex != 0)
            {
                Escribir.WriteLine(cbox_c.Text + "-#");

                String materia = "Materias/" + cbox_c.Text + ".txt";
                StreamWriter Inscripcion = new StreamWriter(materia, true);
                Inscripcion.WriteLine(Registro_new_student.Carnet + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-#");
                Inscripcion.Close();
            }
            if (cbox_d.SelectedIndex != 0)
            {
                Escribir.WriteLine(cbox_d.Text + "-#");

                String materia = "Materias/" + cbox_d.Text + ".txt";
                StreamWriter Inscripcion = new StreamWriter(materia, true);
                Inscripcion.WriteLine(Registro_new_student.Carnet + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-#");
                Inscripcion.Close();
            }
            if (cbox_e.SelectedIndex != 0)
            {
                Escribir.WriteLine(cbox_e.Text + "-#");

                String materia = "Materias/" + cbox_e.Text + ".txt";
                StreamWriter Inscripcion = new StreamWriter(materia, true);
                Inscripcion.WriteLine(Registro_new_student.Carnet + "-" + Registro_new_student.Apellido + "-" + Registro_new_student.Nombre + "-" + Registro_new_student.Correo + "-#");
                Inscripcion.Close();
            }
            Escribir.Close();

        }

        
    }
}
