﻿namespace Proyecto_V1
{
    partial class Form_Pag_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Alumnos = new System.Windows.Forms.Label();
            this.lbl_Cerrar_Sesion = new System.Windows.Forms.Label();
            this.lbl_usuarios = new System.Windows.Forms.Label();
            this.lbl_Docentes = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_contenedor = new System.Windows.Forms.Panel();
            this.lbl_Materias = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(60, 229);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Principal";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_V1.Properties.Resources.WhatsApp_Image_2020_09_20_at_7_29_08_PM;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(48, 653);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Creditos";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl_Alumnos
            // 
            this.lbl_Alumnos.AutoSize = true;
            this.lbl_Alumnos.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Alumnos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Alumnos.Location = new System.Drawing.Point(54, 292);
            this.lbl_Alumnos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Alumnos.Name = "lbl_Alumnos";
            this.lbl_Alumnos.Size = new System.Drawing.Size(85, 24);
            this.lbl_Alumnos.TabIndex = 4;
            this.lbl_Alumnos.Text = "Alumnos";
            this.lbl_Alumnos.Click += new System.EventHandler(this.lbl_Registro_Click);
            // 
            // lbl_Cerrar_Sesion
            // 
            this.lbl_Cerrar_Sesion.AutoSize = true;
            this.lbl_Cerrar_Sesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cerrar_Sesion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Cerrar_Sesion.Location = new System.Drawing.Point(60, 567);
            this.lbl_Cerrar_Sesion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Cerrar_Sesion.Name = "lbl_Cerrar_Sesion";
            this.lbl_Cerrar_Sesion.Size = new System.Drawing.Size(68, 48);
            this.lbl_Cerrar_Sesion.TabIndex = 5;
            this.lbl_Cerrar_Sesion.Text = "Cerrar\r\nSesion";
            this.lbl_Cerrar_Sesion.Click += new System.EventHandler(this.lbl_Cerrar_Sesion_Click);
            // 
            // lbl_usuarios
            // 
            this.lbl_usuarios.AutoSize = true;
            this.lbl_usuarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_usuarios.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_usuarios.Location = new System.Drawing.Point(49, 503);
            this.lbl_usuarios.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_usuarios.Name = "lbl_usuarios";
            this.lbl_usuarios.Size = new System.Drawing.Size(83, 24);
            this.lbl_usuarios.TabIndex = 6;
            this.lbl_usuarios.Text = "Usuarios";
            this.lbl_usuarios.Click += new System.EventHandler(this.lbl_usuarios_Click);
            // 
            // lbl_Docentes
            // 
            this.lbl_Docentes.AutoSize = true;
            this.lbl_Docentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Docentes.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Docentes.Location = new System.Drawing.Point(52, 440);
            this.lbl_Docentes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Docentes.Name = "lbl_Docentes";
            this.lbl_Docentes.Size = new System.Drawing.Size(90, 24);
            this.lbl_Docentes.TabIndex = 7;
            this.lbl_Docentes.Text = "Docentes";
            this.lbl_Docentes.Click += new System.EventHandler(this.lbl_Docentes_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbl_Materias);
            this.panel1.Controls.Add(this.lbl_Docentes);
            this.panel1.Controls.Add(this.lbl_usuarios);
            this.panel1.Controls.Add(this.lbl_Cerrar_Sesion);
            this.panel1.Controls.Add(this.lbl_Alumnos);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(203, 727);
            this.panel1.TabIndex = 0;
            // 
            // panel_contenedor
            // 
            this.panel_contenedor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_contenedor.Location = new System.Drawing.Point(203, -1);
            this.panel_contenedor.Name = "panel_contenedor";
            this.panel_contenedor.Size = new System.Drawing.Size(1041, 727);
            this.panel_contenedor.TabIndex = 3;
            // 
            // lbl_Materias
            // 
            this.lbl_Materias.AutoSize = true;
            this.lbl_Materias.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Materias.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Materias.Location = new System.Drawing.Point(54, 366);
            this.lbl_Materias.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Materias.Name = "lbl_Materias";
            this.lbl_Materias.Size = new System.Drawing.Size(80, 24);
            this.lbl_Materias.TabIndex = 8;
            this.lbl_Materias.Text = "Materias";
            this.lbl_Materias.Click += new System.EventHandler(this.lbl_Materias_Click);
            // 
            // Form_Pag_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1243, 726);
            this.Controls.Add(this.panel_contenedor);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form_Pag_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Alumnos;
        private System.Windows.Forms.Label lbl_Cerrar_Sesion;
        private System.Windows.Forms.Label lbl_usuarios;
        private System.Windows.Forms.Label lbl_Docentes;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_contenedor;
        private System.Windows.Forms.Label lbl_Materias;
    }
}