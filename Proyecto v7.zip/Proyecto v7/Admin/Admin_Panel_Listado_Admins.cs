﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Panel_Listado_Admins : Form
    {
        static StreamReader leer_docentes;
        List<string> listado_admins = new List<string>();
        List<string> Contra = new List<string>();

        public Admin_Panel_Listado_Admins()
        {
            InitializeComponent();
        }

        private void Admin_Panel_Listado_Admins_Load(object sender, EventArgs e)
        {
            Llenar();
        }

        public void Llenar()
        {

            StreamReader leer_alumnos = new StreamReader("User_Admin.txt");
            string[] columnnnames = leer_alumnos.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = leer_alumnos.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            leer_alumnos.Close();
            Dgrid_Admin.DataSource = dt;
            Dgrid_Admin.AutoResizeColumns();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Llenar();
        }

        private void btt_new_Admin_Click(object sender, EventArgs e)
        {
            Admin_Ventana_Nuevo_Admin Ventanita = new Admin_Ventana_Nuevo_Admin();
            Ventanita.Show();
        }
    }
}
