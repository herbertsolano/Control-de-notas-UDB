﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Ventana_Registro_Materias_Docente : Form
    {
        static StreamWriter Escribir;

        List<string> Listado_Materia = new List<string>();
        List<string> Materia_Tipo = new List<string>();
        List<string> Materia_UV = new List<string>();

        public Admin_Ventana_Registro_Materias_Docente()
        {
            InitializeComponent();
        }

        private void bbt_Ingresar_Click(object sender, EventArgs e)
        {
            if(cbox_a.SelectedItem == null || cbox_b.SelectedItem == null|| cbox_c.SelectedItem == null) 
            {
                MessageBox.Show("Error, Cambpos Vacios");
                return;
            }

            string f_name = "Docentes/"+Registro.Nuevo_carnet + ".txt";
            Escribir = new StreamWriter(f_name, true);
            Escribir.WriteLine(cbox_a.Text);
            Escribir.WriteLine(cbox_b.Text);
            Escribir.WriteLine(cbox_c.Text);
            Escribir.Close();

            MessageBox.Show("Docente y materias ingresadas correctamente");
            this.Close();
        }

        private void Admin_Ventana_Registro_Materias_Docente_Load(object sender, EventArgs e)
        {
            StreamReader leer_materias = new StreamReader("Data_Materias.txt");

            String element = "";

            while ((element = leer_materias.ReadLine()) != null)
            {
                
                Listado_Materia.Add(element);
            }
            leer_materias.Close();

            foreach(string elemento in Listado_Materia) 
            {
                if (elemento != "Materia-UV") 
                {
                    cbox_a.Items.Add(elemento);
                    cbox_b.Items.Add(elemento);
                    cbox_c.Items.Add(elemento);
                }
            }

        }
    }
}
