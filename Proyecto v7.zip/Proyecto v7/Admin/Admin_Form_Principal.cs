﻿using Proyecto_V1.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1
{
    public partial class Form_Pag_Principal : Form
    {
        public Form_Pag_Principal()
        {
            InitializeComponent();
            AbrirFormCum(new Panel_Principal());
        }

        private void lbl_Cerrar_Sesion_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Autenticacion ir_autenticacion = new Form_Autenticacion();
            ir_autenticacion.Show();
        }
        private void AbrirFormCum(object formcum) 
        {
            if (this.panel_contenedor.Controls.Count > 0)
                this.panel_contenedor.Controls.RemoveAt(0);// Eliminacion de control

            Form AbrirCum = formcum as Form; //Creacion de formulario
            AbrirCum.TopLevel = false;
            AbrirCum.Dock = DockStyle.Fill;

            this.panel_contenedor.Controls.Add(AbrirCum);
            this.panel_contenedor.Tag = AbrirCum;
            AbrirCum.Show();

        }

        private void lbl_Registro_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Form_Registro_Alumno());
        }

        private void label1_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Panel_Principal());
        }

        private void label2_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Panel_Creditos());
        }

        private void lbl_usuarios_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Admin_Panel_Listado_Admins());
        }

        

        private void lbl_Docentes_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Admin_Panel_Listado_Docentes());
        }

        private void panel_contenedor_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl_Materias_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Admin_Panel_Listado_Materias());
        }
    }
}
    