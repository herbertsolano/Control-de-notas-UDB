﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Panel_Listado_Materias : Form
    {
        public Admin_Panel_Listado_Materias()
        {
            InitializeComponent();
        }

        private void Admin_Panel_Listado_Materias_Load(object sender, EventArgs e)
        {
            Llenar();
        }
        public void Llenar()
        {
             StreamReader leer_materias;
            leer_materias = new StreamReader("Data_Materias.txt");
            string[] columnnnames = leer_materias.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = leer_materias.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            leer_materias.Close();
            Dgrid_Materias.DataSource = dt;
            Dgrid_Materias.AutoResizeColumns();
        }


        private void btt_lista_Materia_Click(object sender, EventArgs e)
        {

            Llenar();
        }

        private void btt_agregar_Materia_Click(object sender, EventArgs e)
        {

            Admin_Ventana_Nueva_Materia Ventanita = new Admin_Ventana_Nueva_Materia();
            Ventanita.Show();
        }
    }
}
