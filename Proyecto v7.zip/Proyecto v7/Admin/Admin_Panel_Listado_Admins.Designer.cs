﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Panel_Listado_Admins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btt_new_Admin = new System.Windows.Forms.Button();
            this.Dgrid_Admin = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Admin)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(192, 44);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1011, 69);
            this.label1.TabIndex = 121;
            this.label1.Text = "LISTADO DE ADMINISTRADORES";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1114, 212);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(248, 79);
            this.button1.TabIndex = 120;
            this.button1.Text = "Actualizar Lista";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btt_new_Admin
            // 
            this.btt_new_Admin.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_new_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_new_Admin.Location = new System.Drawing.Point(1114, 337);
            this.btt_new_Admin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btt_new_Admin.Name = "btt_new_Admin";
            this.btt_new_Admin.Size = new System.Drawing.Size(248, 102);
            this.btt_new_Admin.TabIndex = 117;
            this.btt_new_Admin.Text = "Nuevo Administrador";
            this.btt_new_Admin.UseVisualStyleBackColor = false;
            this.btt_new_Admin.Click += new System.EventHandler(this.btt_new_Admin_Click);
            // 
            // Dgrid_Admin
            // 
            this.Dgrid_Admin.AllowUserToAddRows = false;
            this.Dgrid_Admin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgrid_Admin.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Dgrid_Admin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgrid_Admin.Location = new System.Drawing.Point(47, 212);
            this.Dgrid_Admin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Dgrid_Admin.Name = "Dgrid_Admin";
            this.Dgrid_Admin.ReadOnly = true;
            this.Dgrid_Admin.RowHeadersWidth = 51;
            this.Dgrid_Admin.RowTemplate.Height = 24;
            this.Dgrid_Admin.Size = new System.Drawing.Size(1037, 641);
            this.Dgrid_Admin.TabIndex = 116;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-13, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1404, 159);
            this.panel1.TabIndex = 122;
            // 
            // Admin_Panel_Listado_Admins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1388, 895);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btt_new_Admin);
            this.Controls.Add(this.Dgrid_Admin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Admin_Panel_Listado_Admins";
            this.Text = "Admin_Panel_Listado_Admins";
            this.Load += new System.EventHandler(this.Admin_Panel_Listado_Admins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Admin)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btt_new_Admin;
        private System.Windows.Forms.DataGridView Dgrid_Admin;
        private System.Windows.Forms.Panel panel1;
    }
}