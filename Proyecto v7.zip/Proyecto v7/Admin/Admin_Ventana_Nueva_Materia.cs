﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    
    public partial class Admin_Ventana_Nueva_Materia : Form
    {
        static StreamWriter Escribir;
        List<String> Listado_Materias = new List<string>();

        public Admin_Ventana_Nueva_Materia()
        {
            InitializeComponent();
        }

        private void btt_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_registrar_Click(object sender, EventArgs e)
        {

            if(txt_Nombre != null) 
            {
                foreach(string palabras in Listado_Materias) 
                {
                    if (txt_Nombre.Text == palabras) 
                    {
                        MessageBox.Show("Error. Materia ya registrada");
                        return;
                    }
                }

                string n_file, text_n;
                Escribir = new StreamWriter("Data_Materias.txt", true);

                
                if (check_Lab.Checked == true) 
                {
                    n_file = txt_Nombre.Text + "_L-" + nup_UV.Value;
                }
                else
                    n_file = txt_Nombre.Text + "_T-" + nup_UV.Value;

                Escribir.WriteLine(n_file);
                Escribir.Close();

                text_n ="Materias/"+ n_file + ".txt";
                StreamWriter writer = File.CreateText(text_n);
                writer.Close();

                StreamWriter Primera_l = new StreamWriter(text_n, true);
                Primera_l.WriteLine("Carnet-Apellido-Nombre-Correo-Nota");
                Primera_l.Close();

                txt_Nombre.Clear();
                nup_UV.Value = 2;
                MessageBox.Show("Materia registrada correctamente");
            }

        }

        public void Leeyendo() 
        {
            StreamReader leer_materias = new StreamReader("Data_Materias.txt");

            String element = "";

            while ((element = leer_materias.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = element.Split(delimitador);
                Listado_Materias.Add(components[0]);
            }
            leer_materias.Close();
        }

        private void Admin_Ventana_Nueva_Materia_Load(object sender, EventArgs e)
        {
            Leeyendo();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
} 
