﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Ventana_Nueva_Materia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nup_UV = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.check_Lab = new System.Windows.Forms.CheckBox();
            this.btt_cancelar = new System.Windows.Forms.Button();
            this.btt_registrar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nup_UV)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre.Location = new System.Drawing.Point(266, 111);
            this.txt_Nombre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(479, 30);
            this.txt_Nombre.TabIndex = 96;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(116, 105);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 39);
            this.label2.TabIndex = 97;
            this.label2.Text = "Materia:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // nup_UV
            // 
            this.nup_UV.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nup_UV.Location = new System.Drawing.Point(402, 176);
            this.nup_UV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nup_UV.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nup_UV.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nup_UV.Name = "nup_UV";
            this.nup_UV.Size = new System.Drawing.Size(64, 41);
            this.nup_UV.TabIndex = 99;
            this.nup_UV.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(335, 180);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 39);
            this.label1.TabIndex = 100;
            this.label1.Text = "UV";
            // 
            // check_Lab
            // 
            this.check_Lab.AutoSize = true;
            this.check_Lab.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_Lab.Location = new System.Drawing.Point(123, 176);
            this.check_Lab.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.check_Lab.Name = "check_Lab";
            this.check_Lab.Size = new System.Drawing.Size(204, 43);
            this.check_Lab.TabIndex = 101;
            this.check_Lab.Text = "Laboratorio";
            this.check_Lab.UseVisualStyleBackColor = true;
            // 
            // btt_cancelar
            // 
            this.btt_cancelar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar.Location = new System.Drawing.Point(525, 284);
            this.btt_cancelar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btt_cancelar.Name = "btt_cancelar";
            this.btt_cancelar.Size = new System.Drawing.Size(220, 65);
            this.btt_cancelar.TabIndex = 106;
            this.btt_cancelar.Text = "Cancelar";
            this.btt_cancelar.UseVisualStyleBackColor = false;
            this.btt_cancelar.Click += new System.EventHandler(this.btt_cancelar_Click);
            // 
            // btt_registrar
            // 
            this.btt_registrar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_registrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_registrar.Location = new System.Drawing.Point(266, 284);
            this.btt_registrar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btt_registrar.Name = "btt_registrar";
            this.btt_registrar.Size = new System.Drawing.Size(220, 65);
            this.btt_registrar.TabIndex = 105;
            this.btt_registrar.Text = "Registrar";
            this.btt_registrar.UseVisualStyleBackColor = false;
            this.btt_registrar.Click += new System.EventHandler(this.btt_registrar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-7, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(825, 84);
            this.panel1.TabIndex = 108;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(221, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(368, 39);
            this.label3.TabIndex = 109;
            this.label3.Text = "REGISTRO DE MATERIAS";
            // 
            // Admin_Ventana_Nueva_Materia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(810, 408);
            this.Controls.Add(this.btt_cancelar);
            this.Controls.Add(this.btt_registrar);
            this.Controls.Add(this.check_Lab);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Nombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nup_UV);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Admin_Ventana_Nueva_Materia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Ventana_Nueva_Materia";
            this.Load += new System.EventHandler(this.Admin_Ventana_Nueva_Materia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nup_UV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nup_UV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox check_Lab;
        private System.Windows.Forms.Button btt_cancelar;
        private System.Windows.Forms.Button btt_registrar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}