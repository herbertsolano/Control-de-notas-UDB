﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Ventana_Nuevo_Admin : Form
    {
        public Admin_Ventana_Nuevo_Admin()
        {
            InitializeComponent();
        }

        private void btt_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        struct Nuevo_Admin
        {
            public string carnet, nombre, apellido, correo, contraseña;

        }

        private void btt_registrar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text != "" || txt_Carnet.Text != "" || txt_Contraseña.Text != "" || txt_lname.Text != "" || txt_email.Text != "")
            {
                Nuevo_Admin Nuevito = new Nuevo_Admin();
                Nuevito.carnet = txt_Carnet.Text;
                Nuevito.nombre = txtNombre.Text;
                Nuevito.apellido = txt_lname.Text;
                Nuevito.correo = txt_email.Text;
                Nuevito.contraseña = txt_Contraseña.Text;

                StreamWriter Escribir;
                Escribir = new StreamWriter("User_Admin.txt", true);
                Escribir.WriteLine(txt_Carnet.Text + "-" + txt_Contraseña.Text + "-" + txt_lname.Text + "-" + txtNombre.Text + "-" + txt_email.Text);
                Escribir.Close();

                txtNombre.Clear();
                txt_lname.Clear();
                txt_email.Clear();
                txt_Carnet.Clear();
                txt_Contraseña.Clear();

                return;
            }
            else
            {
                MessageBox.Show("HAY ESPACIOS INCOMPLETOS");
            }
        }
    }

}
