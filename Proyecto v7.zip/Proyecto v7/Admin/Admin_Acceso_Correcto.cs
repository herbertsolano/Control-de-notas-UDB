﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1
{
    public partial class Admin_Acceso_Correcto : Form
    {
        public Admin_Acceso_Correcto()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            timer1.Stop();
            Form_Pag_Principal ir_principal = new Form_Pag_Principal();
            ir_principal.Show();
            this.Close();
        }

        private void Admin_Acceso_Correcto_Load(object sender, EventArgs e)
        {

        }
    }
}
