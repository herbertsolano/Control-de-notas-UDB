﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1
{
    public partial class Panel_Calculo_Cum : Form
    {
        public Panel_Calculo_Cum()
        {
            InitializeComponent();
        }

        private void txtUnidades_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkLab_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btt_new_materia_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
