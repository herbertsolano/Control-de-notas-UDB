﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Panel_Listado_Docentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btt_new_docente = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Dgrid_Docentes = new System.Windows.Forms.DataGridView();
            this.btt_actualizar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Docentes)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btt_new_docente
            // 
            this.btt_new_docente.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_new_docente.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_new_docente.Location = new System.Drawing.Point(1161, 321);
            this.btt_new_docente.Margin = new System.Windows.Forms.Padding(4);
            this.btt_new_docente.Name = "btt_new_docente";
            this.btt_new_docente.Size = new System.Drawing.Size(190, 109);
            this.btt_new_docente.TabIndex = 119;
            this.btt_new_docente.Text = "Nuevo Docente";
            this.btt_new_docente.UseVisualStyleBackColor = false;
            this.btt_new_docente.Click += new System.EventHandler(this.btt_new_materia_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(296, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(754, 69);
            this.label1.TabIndex = 114;
            this.label1.Text = "LISTADO DE DOCENTES";
            // 
            // Dgrid_Docentes
            // 
            this.Dgrid_Docentes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgrid_Docentes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Dgrid_Docentes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgrid_Docentes.Location = new System.Drawing.Point(27, 183);
            this.Dgrid_Docentes.Margin = new System.Windows.Forms.Padding(4);
            this.Dgrid_Docentes.Name = "Dgrid_Docentes";
            this.Dgrid_Docentes.ReadOnly = true;
            this.Dgrid_Docentes.RowHeadersWidth = 51;
            this.Dgrid_Docentes.RowTemplate.Height = 24;
            this.Dgrid_Docentes.Size = new System.Drawing.Size(1103, 674);
            this.Dgrid_Docentes.TabIndex = 122;
            this.Dgrid_Docentes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgrid_Docentes_CellContentClick);
            // 
            // btt_actualizar
            // 
            this.btt_actualizar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_actualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_actualizar.Location = new System.Drawing.Point(1161, 183);
            this.btt_actualizar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_actualizar.Name = "btt_actualizar";
            this.btt_actualizar.Size = new System.Drawing.Size(190, 114);
            this.btt_actualizar.TabIndex = 123;
            this.btt_actualizar.Text = "Actualizar lista";
            this.btt_actualizar.UseVisualStyleBackColor = false;
            this.btt_actualizar.Click += new System.EventHandler(this.btt_actualizar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1398, 142);
            this.panel1.TabIndex = 124;
            // 
            // Admin_Panel_Listado_Docentes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(1388, 895);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btt_actualizar);
            this.Controls.Add(this.Dgrid_Docentes);
            this.Controls.Add(this.btt_new_docente);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Admin_Panel_Listado_Docentes";
            this.Text = "Admin_Panel_Listado_Docentes";
            this.Load += new System.EventHandler(this.Admin_Panel_Listado_Docentes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Docentes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btt_new_docente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Dgrid_Docentes;
        private System.Windows.Forms.Button btt_actualizar;
        private System.Windows.Forms.Panel panel1;
    }
}