﻿namespace Proyecto_V1.Admin
{
    partial class Admin_Ventana_Registro_Materias_Docente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbox_c = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbox_b = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox_a = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bbt_Ingresar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbox_c
            // 
            this.cbox_c.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cbox_c.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_c.FormattingEnabled = true;
            this.cbox_c.Location = new System.Drawing.Point(315, 297);
            this.cbox_c.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_c.Name = "cbox_c";
            this.cbox_c.Size = new System.Drawing.Size(311, 33);
            this.cbox_c.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(141, 294);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 32);
            this.label3.TabIndex = 11;
            this.label3.Text = "Materia :";
            // 
            // cbox_b
            // 
            this.cbox_b.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cbox_b.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_b.FormattingEnabled = true;
            this.cbox_b.Location = new System.Drawing.Point(315, 227);
            this.cbox_b.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_b.Name = "cbox_b";
            this.cbox_b.Size = new System.Drawing.Size(311, 33);
            this.cbox_b.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(141, 224);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 32);
            this.label2.TabIndex = 9;
            this.label2.Text = "Materia :";
            // 
            // cbox_a
            // 
            this.cbox_a.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cbox_a.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_a.FormattingEnabled = true;
            this.cbox_a.Location = new System.Drawing.Point(315, 159);
            this.cbox_a.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbox_a.Name = "cbox_a";
            this.cbox_a.Size = new System.Drawing.Size(311, 33);
            this.cbox_a.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(141, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Materia :";
            // 
            // bbt_Ingresar
            // 
            this.bbt_Ingresar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bbt_Ingresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbt_Ingresar.Location = new System.Drawing.Point(664, 383);
            this.bbt_Ingresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bbt_Ingresar.Name = "bbt_Ingresar";
            this.bbt_Ingresar.Size = new System.Drawing.Size(173, 61);
            this.bbt_Ingresar.TabIndex = 13;
            this.bbt_Ingresar.Text = "Ingresar";
            this.bbt_Ingresar.UseVisualStyleBackColor = false;
            this.bbt_Ingresar.Click += new System.EventHandler(this.bbt_Ingresar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(233, 37);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(424, 52);
            this.label4.TabIndex = 14;
            this.label4.Text = "Materias Asignadas";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(887, 129);
            this.panel1.TabIndex = 15;
            // 
            // Admin_Ventana_Registro_Materias_Docente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(884, 496);
            this.Controls.Add(this.bbt_Ingresar);
            this.Controls.Add(this.cbox_c);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbox_b);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbox_a);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Admin_Ventana_Registro_Materias_Docente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Ventana_Registro_Materias_Docente";
            this.Load += new System.EventHandler(this.Admin_Ventana_Registro_Materias_Docente_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbox_c;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbox_b;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox_a;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bbt_Ingresar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
    }
}