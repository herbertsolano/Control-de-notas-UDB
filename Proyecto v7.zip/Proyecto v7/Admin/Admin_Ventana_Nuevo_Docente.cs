﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace Proyecto_V1.Admin
{
    public partial class Admin_Ventana_Nuevo_Docente : Form
    {
        //Variable para escribir archivos
        static StreamWriter Escribir;

        public Admin_Ventana_Nuevo_Docente()
        {
            InitializeComponent();
        }

        private void btt_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        struct Nuevo_Docente
        {
            public string carnet, nombre, apellido,correo, contraseña;

        }

        private void btt_registrar_Click(object sender, EventArgs e)
        {

            //Guardando los datos de los docentes
            if (txtNombre.Text != "" || txt_carnet.Text != "" || txt_Contraseña.Text != "" || txt_lname.Text != "" || txt_email.Text != "")
            {
                Nuevo_Docente Nuevito = new Nuevo_Docente();
                Nuevito.carnet = txt_carnet.Text;
                Nuevito.nombre = txtNombre.Text;
                Nuevito.apellido = txt_lname.Text;
                Nuevito.correo = txt_email.Text;
                Nuevito.contraseña = txt_Contraseña.Text;
                Registro.Nuevo_carnet = Nuevito.carnet;


                Escribir = new StreamWriter("User_Docentes.txt", true);
                Escribir.WriteLine(txt_carnet.Text + "-" + txt_Contraseña.Text + "-" + txt_lname.Text + "-" + txtNombre.Text + "-" + txt_email.Text);
                Escribir.Close();
                //MessageBox.Show("Registro realizado con éxito, para visualizar click en actualizar tabla");
                string f_name = "Docentes/"+txt_carnet.Text + ".txt";
                StreamWriter writer = File.CreateText(f_name);
                writer.Close();
                txtNombre.Clear();
                txt_lname.Clear();
                txt_email.Clear();
                txt_carnet.Clear();
                txt_Contraseña.Clear();
                Admin_Ventana_Registro_Materias_Docente Ventanita = new Admin_Ventana_Registro_Materias_Docente();
                Ventanita.Show();

                return;
            }
            else
            {
                MessageBox.Show("HAY ESPACIOS INCOMPLETOS");
            }
          
        }
        
        private void Admin_Ventana_Nuevo_Docente_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
