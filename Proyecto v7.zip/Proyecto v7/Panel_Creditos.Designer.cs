﻿namespace Proyecto_V1
{
    partial class Panel_Creditos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Panel_Creditos));
            this.lbl_nombres = new System.Windows.Forms.Label();
            this.lbl_gt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_nombres
            // 
            this.lbl_nombres.AutoSize = true;
            this.lbl_nombres.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombres.Location = new System.Drawing.Point(175, 303);
            this.lbl_nombres.Name = "lbl_nombres";
            this.lbl_nombres.Size = new System.Drawing.Size(675, 165);
            this.lbl_nombres.TabIndex = 0;
            this.lbl_nombres.Text = resources.GetString("lbl_nombres.Text");
            // 
            // lbl_gt
            // 
            this.lbl_gt.AutoSize = true;
            this.lbl_gt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gt.Location = new System.Drawing.Point(195, 161);
            this.lbl_gt.Name = "lbl_gt";
            this.lbl_gt.Size = new System.Drawing.Size(625, 37);
            this.lbl_gt.TabIndex = 1;
            this.lbl_gt.Text = "Programación Estructurada PRE104 G04T";
            // 
            // Panel_Creditos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 688);
            this.Controls.Add(this.lbl_gt);
            this.Controls.Add(this.lbl_nombres);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Panel_Creditos";
            this.Text = "Panel_Creditos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nombres;
        private System.Windows.Forms.Label lbl_gt;
    }
}