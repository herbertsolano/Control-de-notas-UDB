﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Acceso_Correcto : Form
    {
        public Docente_Acceso_Correcto()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            timer1.Stop();
            Docente_Form_Principal ir_principal = new Docente_Form_Principal();
            ir_principal.Show();
            this.Close();
        }

        private void Docente_Acceso_Correcto_Load(object sender, EventArgs e)
        {

        }
    }
}
