﻿namespace Proyecto_V1.Docente
{
    partial class Docente_Form_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Informacion = new System.Windows.Forms.Label();
            this.panel_contenedor = new System.Windows.Forms.Panel();
            this.lbl_Cerrar_Sesion = new System.Windows.Forms.Label();
            this.lbl_Registro = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbl_Informacion);
            this.panel1.Controls.Add(this.panel_contenedor);
            this.panel1.Controls.Add(this.lbl_Cerrar_Sesion);
            this.panel1.Controls.Add(this.lbl_Registro);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1234, 727);
            this.panel1.TabIndex = 1;
            // 
            // lbl_Informacion
            // 
            this.lbl_Informacion.AutoSize = true;
            this.lbl_Informacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Informacion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Informacion.Location = new System.Drawing.Point(37, 426);
            this.lbl_Informacion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Informacion.Name = "lbl_Informacion";
            this.lbl_Informacion.Size = new System.Drawing.Size(108, 24);
            this.lbl_Informacion.TabIndex = 6;
            this.lbl_Informacion.Text = "Informacion";
            this.lbl_Informacion.Click += new System.EventHandler(this.lbl_Informacion_Click);
            // 
            // panel_contenedor
            // 
            this.panel_contenedor.BackColor = System.Drawing.Color.White;
            this.panel_contenedor.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel_contenedor.Location = new System.Drawing.Point(201, 1);
            this.panel_contenedor.Name = "panel_contenedor";
            this.panel_contenedor.Size = new System.Drawing.Size(1041, 727);
            this.panel_contenedor.TabIndex = 2;
            this.panel_contenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_contenedor_Paint);
            // 
            // lbl_Cerrar_Sesion
            // 
            this.lbl_Cerrar_Sesion.AutoSize = true;
            this.lbl_Cerrar_Sesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cerrar_Sesion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Cerrar_Sesion.Location = new System.Drawing.Point(30, 517);
            this.lbl_Cerrar_Sesion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Cerrar_Sesion.Name = "lbl_Cerrar_Sesion";
            this.lbl_Cerrar_Sesion.Size = new System.Drawing.Size(122, 24);
            this.lbl_Cerrar_Sesion.TabIndex = 5;
            this.lbl_Cerrar_Sesion.Text = "Cerrar sesion";
            this.lbl_Cerrar_Sesion.Click += new System.EventHandler(this.lbl_Cerrar_Sesion_Click);
            // 
            // lbl_Registro
            // 
            this.lbl_Registro.AutoSize = true;
            this.lbl_Registro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Registro.Location = new System.Drawing.Point(44, 311);
            this.lbl_Registro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Registro.Name = "lbl_Registro";
            this.lbl_Registro.Size = new System.Drawing.Size(95, 48);
            this.lbl_Registro.TabIndex = 4;
            this.lbl_Registro.Text = " Materias \r\nImpartidas";
            this.lbl_Registro.Click += new System.EventHandler(this.lbl_Registro_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(52, 608);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Creditos";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_V1.Properties.Resources.WhatsApp_Image_2020_09_20_at_7_29_08_PM;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(50, 220);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Principal";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Docente_Form_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 726);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Docente_Form_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Docente_Form_Principal";
            this.Load += new System.EventHandler(this.Docente_Form_Principal_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Cerrar_Sesion;
        private System.Windows.Forms.Label lbl_Registro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_contenedor;
        private System.Windows.Forms.Label lbl_Informacion;
    }
}