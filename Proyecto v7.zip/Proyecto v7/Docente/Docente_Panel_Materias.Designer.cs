﻿namespace Proyecto_V1.Docente
{
    partial class Docente_Panel_Materias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Titulo = new System.Windows.Forms.Label();
            this.lbl_Materia1 = new System.Windows.Forms.Label();
            this.lbl_Materia2 = new System.Windows.Forms.Label();
            this.lbl_Materia3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Titulo
            // 
            this.lbl_Titulo.AutoSize = true;
            this.lbl_Titulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Titulo.Location = new System.Drawing.Point(382, 32);
            this.lbl_Titulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Titulo.Name = "lbl_Titulo";
            this.lbl_Titulo.Size = new System.Drawing.Size(573, 69);
            this.lbl_Titulo.TabIndex = 0;
            this.lbl_Titulo.Text = "Materias Impartidas";
            // 
            // lbl_Materia1
            // 
            this.lbl_Materia1.AutoSize = true;
            this.lbl_Materia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Materia1.Location = new System.Drawing.Point(114, 149);
            this.lbl_Materia1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Materia1.Name = "lbl_Materia1";
            this.lbl_Materia1.Size = new System.Drawing.Size(214, 52);
            this.lbl_Materia1.TabIndex = 1;
            this.lbl_Materia1.Text = "Materia 1";
            this.lbl_Materia1.Click += new System.EventHandler(this.lbl_Materia1_Click);
            // 
            // lbl_Materia2
            // 
            this.lbl_Materia2.AutoSize = true;
            this.lbl_Materia2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Materia2.Location = new System.Drawing.Point(114, 301);
            this.lbl_Materia2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Materia2.Name = "lbl_Materia2";
            this.lbl_Materia2.Size = new System.Drawing.Size(214, 52);
            this.lbl_Materia2.TabIndex = 2;
            this.lbl_Materia2.Text = "Materia 2";
            this.lbl_Materia2.Click += new System.EventHandler(this.lbl_Materia2_Click);
            // 
            // lbl_Materia3
            // 
            this.lbl_Materia3.AutoSize = true;
            this.lbl_Materia3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Materia3.Location = new System.Drawing.Point(114, 451);
            this.lbl_Materia3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Materia3.Name = "lbl_Materia3";
            this.lbl_Materia3.Size = new System.Drawing.Size(214, 52);
            this.lbl_Materia3.TabIndex = 3;
            this.lbl_Materia3.Text = "Materia 3";
            this.lbl_Materia3.Click += new System.EventHandler(this.lbl_Materia3_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.lbl_Titulo);
            this.panel1.Location = new System.Drawing.Point(0, -7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1407, 149);
            this.panel1.TabIndex = 131;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Controls.Add(this.lbl_Materia3);
            this.panel2.Controls.Add(this.lbl_Materia2);
            this.panel2.Controls.Add(this.lbl_Materia1);
            this.panel2.Location = new System.Drawing.Point(238, 142);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1154, 758);
            this.panel2.TabIndex = 132;
            // 
            // Docente_Panel_Materias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(1388, 895);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Docente_Panel_Materias";
            this.Text = "Docente_Panel_Materias";
            this.Load += new System.EventHandler(this.Docente_Panel_Materias_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_Titulo;
        private System.Windows.Forms.Label lbl_Materia1;
        private System.Windows.Forms.Label lbl_Materia2;
        private System.Windows.Forms.Label lbl_Materia3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}