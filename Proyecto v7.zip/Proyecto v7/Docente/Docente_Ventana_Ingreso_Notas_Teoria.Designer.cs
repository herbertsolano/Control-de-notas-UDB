﻿namespace Proyecto_V1.Docente
{
    partial class Docente_Ventana_Ingreso_Notas_Teoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nup_nota1 = new System.Windows.Forms.NumericUpDown();
            this.nup_nota2 = new System.Windows.Forms.NumericUpDown();
            this.nup_nota3 = new System.Windows.Forms.NumericUpDown();
            this.lbl_materia = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_nota_final = new System.Windows.Forms.Label();
            this.btt_cancelar = new System.Windows.Forms.Button();
            this.btt_registrar = new System.Windows.Forms.Button();
            this.lbl_alumno = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota3)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(212, 133);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Periodo 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(411, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(239, 55);
            this.label2.TabIndex = 1;
            this.label2.Text = "Periodo 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(609, 133);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 55);
            this.label3.TabIndex = 2;
            this.label3.Text = "Periodo 3";
            // 
            // nup_nota1
            // 
            this.nup_nota1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nup_nota1.DecimalPlaces = 1;
            this.nup_nota1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nup_nota1.Location = new System.Drawing.Point(253, 220);
            this.nup_nota1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nup_nota1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nup_nota1.Name = "nup_nota1";
            this.nup_nota1.Size = new System.Drawing.Size(89, 37);
            this.nup_nota1.TabIndex = 3;
            this.nup_nota1.ValueChanged += new System.EventHandler(this.nup_nota1_ValueChanged);
            // 
            // nup_nota2
            // 
            this.nup_nota2.DecimalPlaces = 1;
            this.nup_nota2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nup_nota2.Location = new System.Drawing.Point(452, 220);
            this.nup_nota2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nup_nota2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nup_nota2.Name = "nup_nota2";
            this.nup_nota2.Size = new System.Drawing.Size(89, 37);
            this.nup_nota2.TabIndex = 4;
            this.nup_nota2.ValueChanged += new System.EventHandler(this.nup_nota2_ValueChanged);
            // 
            // nup_nota3
            // 
            this.nup_nota3.DecimalPlaces = 1;
            this.nup_nota3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nup_nota3.Location = new System.Drawing.Point(646, 220);
            this.nup_nota3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nup_nota3.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nup_nota3.Name = "nup_nota3";
            this.nup_nota3.Size = new System.Drawing.Size(89, 37);
            this.nup_nota3.TabIndex = 5;
            this.nup_nota3.ValueChanged += new System.EventHandler(this.nup_nota3_ValueChanged);
            // 
            // lbl_materia
            // 
            this.lbl_materia.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_materia.AutoSize = true;
            this.lbl_materia.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_materia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_materia.Location = new System.Drawing.Point(353, 22);
            this.lbl_materia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_materia.Name = "lbl_materia";
            this.lbl_materia.Size = new System.Drawing.Size(374, 55);
            this.lbl_materia.TabIndex = 6;
            this.lbl_materia.Text = "LBL _MATERIA";
            this.lbl_materia.Click += new System.EventHandler(this.lbl_materia_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(499, 378);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(283, 55);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nota Final :";
            // 
            // lbl_nota_final
            // 
            this.lbl_nota_final.AutoSize = true;
            this.lbl_nota_final.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nota_final.Location = new System.Drawing.Point(729, 378);
            this.lbl_nota_final.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nota_final.Name = "lbl_nota_final";
            this.lbl_nota_final.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbl_nota_final.Size = new System.Drawing.Size(108, 55);
            this.lbl_nota_final.TabIndex = 8;
            this.lbl_nota_final.Text = "###";
            // 
            // btt_cancelar
            // 
            this.btt_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar.Location = new System.Drawing.Point(234, 333);
            this.btt_cancelar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btt_cancelar.Name = "btt_cancelar";
            this.btt_cancelar.Size = new System.Drawing.Size(189, 64);
            this.btt_cancelar.TabIndex = 108;
            this.btt_cancelar.Text = "Cancelar";
            this.btt_cancelar.UseVisualStyleBackColor = true;
            this.btt_cancelar.Click += new System.EventHandler(this.btt_cancelar_Click);
            // 
            // btt_registrar
            // 
            this.btt_registrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_registrar.Location = new System.Drawing.Point(26, 333);
            this.btt_registrar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btt_registrar.Name = "btt_registrar";
            this.btt_registrar.Size = new System.Drawing.Size(189, 64);
            this.btt_registrar.TabIndex = 107;
            this.btt_registrar.Text = "Registrar";
            this.btt_registrar.UseVisualStyleBackColor = true;
            this.btt_registrar.Click += new System.EventHandler(this.btt_registrar_Click);
            // 
            // lbl_alumno
            // 
            this.lbl_alumno.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_alumno.AutoSize = true;
            this.lbl_alumno.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_alumno.Location = new System.Drawing.Point(40, 34);
            this.lbl_alumno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_alumno.Name = "lbl_alumno";
            this.lbl_alumno.Size = new System.Drawing.Size(196, 39);
            this.lbl_alumno.TabIndex = 109;
            this.lbl_alumno.Text = "lbl_nombre";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.lbl_materia);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1069, 102);
            this.panel1.TabIndex = 110;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Controls.Add(this.nup_nota1);
            this.panel2.Controls.Add(this.lbl_alumno);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.nup_nota2);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.nup_nota3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btt_cancelar);
            this.panel2.Controls.Add(this.lbl_nota_final);
            this.panel2.Controls.Add(this.btt_registrar);
            this.panel2.Location = new System.Drawing.Point(169, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(900, 510);
            this.panel2.TabIndex = 7;
            // 
            // Docente_Ventana_Ingreso_Notas_Teoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 611);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Docente_Ventana_Ingreso_Notas_Teoria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Docente_Ventana_Ingreso_Notas_Teoria";
            this.Load += new System.EventHandler(this.Docente_Ventana_Ingreso_Notas_Teoria_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nup_nota3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nup_nota1;
        private System.Windows.Forms.NumericUpDown nup_nota2;
        private System.Windows.Forms.NumericUpDown nup_nota3;
        private System.Windows.Forms.Label lbl_materia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_nota_final;
        private System.Windows.Forms.Button btt_cancelar;
        private System.Windows.Forms.Button btt_registrar;
        private System.Windows.Forms.Label lbl_alumno;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}