﻿namespace Proyecto_V1.Docente
{
    partial class Docente_Panel_Materia_Notas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbl_materia = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Dgrid_Alumnos = new System.Windows.Forms.DataGridView();
            this.btt_salir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Alumnos)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_materia
            // 
            this.lbl_materia.AutoSize = true;
            this.lbl_materia.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_materia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_materia.Location = new System.Drawing.Point(284, 32);
            this.lbl_materia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_materia.Name = "lbl_materia";
            this.lbl_materia.Size = new System.Drawing.Size(716, 69);
            this.lbl_materia.TabIndex = 127;
            this.lbl_materia.Text = "LISTADO DE ALUMNOS";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1112, 181);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 68);
            this.button1.TabIndex = 126;
            this.button1.Text = "Actualizar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Dgrid_Alumnos
            // 
            this.Dgrid_Alumnos.AllowUserToAddRows = false;
            this.Dgrid_Alumnos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgrid_Alumnos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Dgrid_Alumnos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgrid_Alumnos.Location = new System.Drawing.Point(91, 182);
            this.Dgrid_Alumnos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Dgrid_Alumnos.Name = "Dgrid_Alumnos";
            this.Dgrid_Alumnos.ReadOnly = true;
            this.Dgrid_Alumnos.RowHeadersWidth = 51;
            this.Dgrid_Alumnos.RowTemplate.Height = 24;
            this.Dgrid_Alumnos.Size = new System.Drawing.Size(996, 632);
            this.Dgrid_Alumnos.TabIndex = 122;
            this.Dgrid_Alumnos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgrid_Admin_CellClick);
            // 
            // btt_salir
            // 
            this.btt_salir.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_salir.Location = new System.Drawing.Point(1112, 269);
            this.btt_salir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btt_salir.Name = "btt_salir";
            this.btt_salir.Size = new System.Drawing.Size(193, 67);
            this.btt_salir.TabIndex = 129;
            this.btt_salir.Text = "Salir";
            this.btt_salir.UseVisualStyleBackColor = true;
            this.btt_salir.Click += new System.EventHandler(this.btt_salir_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.lbl_materia);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1388, 130);
            this.panel1.TabIndex = 130;
            // 
            // Docente_Panel_Materia_Notas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1388, 895);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btt_salir);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Dgrid_Alumnos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Docente_Panel_Materia_Notas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Docente_Panel_Materia_Notas";
            this.Load += new System.EventHandler(this.Docente_Panel_Materia_Notas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgrid_Alumnos)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_materia;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView Dgrid_Alumnos;
        private System.Windows.Forms.Button btt_salir;
        private System.Windows.Forms.Panel panel1;
    }
}