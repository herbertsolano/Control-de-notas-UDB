﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_V1
{
    public class Datos_Materias
    {
        static public string Inicio_Carnet, Inicio_Nombre, Inicio_Apellido, Inicio_Email,Inicio_Carrera;

        static public string Ingreso_Materia, Ingreso_Alumno, Ingreso_Tipo, Ingreso_Nombre, Ingreso_Apellido, Ingreso_Email;
        static public double Calificacion;
    }
}
