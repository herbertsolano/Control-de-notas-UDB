﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Ventana_Ingreso_Notas_Lab : Form
    {
        string f_name = "Estudiantes/" + Datos_Materias.Ingreso_Alumno + ".txt";
        string f_materia = "Materias/" + Datos_Materias.Ingreso_Materia + ".txt";

        List<string> Lineas = new List<string>();
        List<string> Listado_notas = new List<string>();

        public Docente_Ventana_Ingreso_Notas_Lab()
        {
            InitializeComponent();
        }

        private void btt_registrar_Click(object sender, EventArgs e)
        {
            DialogResult Respuesta = MessageBox.Show("¿Esta seguro de ingresar notas?", "Confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

            if (Respuesta == DialogResult.Yes)
            {
                Datos_Materias.Calificacion = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;


                int cell;
                string linea = Datos_Materias.Ingreso_Materia + "-#";

                cell = Lineas.IndexOf(linea);
                Lineas[cell] = Datos_Materias.Ingreso_Materia + "-" + Datos_Materias.Calificacion;

                using (var writetext = new StreamWriter("Estudiantes/temp.txt"))
                {
                    foreach (string yes in Lineas)
                    {
                        writetext.WriteLine(yes);
                    }
                }

                File.Delete(f_name);
                File.Move("Estudiantes/temp.txt", f_name);
                MessageBox.Show("Nota Ingresada en alumno");

                string linea2 = Datos_Materias.Ingreso_Alumno + "-" + Datos_Materias.Ingreso_Apellido + "-" + Datos_Materias.Ingreso_Nombre + "-" + Datos_Materias.Ingreso_Email + "-#";
                cell = Listado_notas.IndexOf(linea2);
                Listado_notas[cell] = Datos_Materias.Ingreso_Alumno + "-" + Datos_Materias.Ingreso_Apellido + "-" + Datos_Materias.Ingreso_Nombre + "-" + Datos_Materias.Ingreso_Email + "-" + Datos_Materias.Calificacion;

                using (var writetext = new StreamWriter("Materias/temp.txt"))
                {
                    foreach (string yes in Listado_notas)
                    {
                        writetext.WriteLine(yes);
                    }
                }
                File.Delete(f_materia);
                File.Move("Materias/temp.txt", f_materia);
                MessageBox.Show("Nota Ingresada en listado de alumnos");

                this.Close();
            }
        }

        private void btt_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void Docente_Ventana_Ingreso_Notas_Lab_Load(object sender, EventArgs e)
        {
            lbl_materia.Text = Datos_Materias.Ingreso_Materia;
            lbl_alumno.Text = "Carnet: " + Datos_Materias.Ingreso_Alumno;
            Leer_Lineas();
            Leer_Listado_Notas();
        }


        public void Leer_Lineas()
        {

            StreamReader Leer = new StreamReader(f_name);

            String element = "";

            while ((element = Leer.ReadLine()) != null)
            {
                Lineas.Add(element);
            }
            Leer.Close();
        }

        public void Leer_Listado_Notas()
        {

            StreamReader Leer = new StreamReader(f_materia);

            String element = "";

            while ((element = Leer.ReadLine()) != null)
            {
                Listado_notas.Add(element);
            }
            Leer.Close();
        }

        private void nup_nota1_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }

        private void nup_Lab1_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }

        private void nup_nota2_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }

        private void nup_Lab2_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }

        private void nup_nota3_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }

        private void nup_Lab3_ValueChanged(object sender, EventArgs e)
        {
            double nota = Convert.ToDouble(nup_nota1.Value) * 0.2 + Convert.ToDouble(nup_nota2.Value) * 0.2 + Convert.ToDouble(nup_nota3.Value) * 0.2 + Convert.ToDouble(nup_Lab1.Value) * 0.1 + Convert.ToDouble(nup_Lab2.Value) * 0.15 + Convert.ToDouble(nup_Lab3.Value) * 0.15;
            lbl_nota_final.Text = Convert.ToString(nota);
        }
    }
}
