﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Panel_Materia_Notas : Form
    {
        int fila;
        static string Materia_file = "Materias/" + Datos_docente.Materia1 + ".txt";
        public Docente_Panel_Materia_Notas()
        {
            InitializeComponent();
        }

        private void Docente_Panel_Materia_Notas_Load(object sender, EventArgs e)
        {
            lbl_materia.Text = Datos_Materias.Ingreso_Materia;

            char[] delimitador = { '_', '-' };
            string[] components = Datos_Materias.Ingreso_Materia.Split(delimitador);
            string tipo = components[1];

            if (tipo == "T")
            {
                Datos_Materias.Ingreso_Tipo = "T";
            }
            if (tipo == "L")
                Datos_Materias.Ingreso_Tipo = "L";

            Leer_Alumnos();
        }

        private void Dgrid_Admin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            fila = Dgrid_Alumnos.CurrentRow.Index;

            if(Convert.ToString(Dgrid_Alumnos[4, fila].Value) != "#") 
            {
                MessageBox.Show("El alumno ya posee nota ingresada");
            }
            if (Convert.ToString(Dgrid_Alumnos[4, fila].Value) == "#") 
            {
                Datos_Materias.Ingreso_Alumno = Convert.ToString(Dgrid_Alumnos[0, fila].Value);
                Datos_Materias.Ingreso_Apellido = Convert.ToString(Dgrid_Alumnos[1, fila].Value);
                Datos_Materias.Ingreso_Nombre = Convert.ToString(Dgrid_Alumnos[2, fila].Value);
                Datos_Materias.Ingreso_Email = Convert.ToString(Dgrid_Alumnos[3, fila].Value);

                if (Datos_Materias.Ingreso_Tipo== "T") 
                {
                    Docente_Ventana_Ingreso_Notas_Teoria Ventanita = new Docente_Ventana_Ingreso_Notas_Teoria();
                    Ventanita.Show();
                }
                if (Datos_Materias.Ingreso_Tipo == "L")
                {
                    Docente_Ventana_Ingreso_Notas_Lab Ventanita = new Docente_Ventana_Ingreso_Notas_Lab();
                    Ventanita.Show();
                }
            }
        }

        private void btt_salir_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        public void Leer_Alumnos() 
        {
            string f_materia = "Materias/" + Datos_Materias.Ingreso_Materia + ".txt";

            StreamReader Lectura = new StreamReader(f_materia);

            string[] columnnnames = Lectura.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = Lectura.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            Lectura.Close();
            Dgrid_Alumnos.DataSource = dt;
            Dgrid_Alumnos.AutoResizeColumns();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Leer_Alumnos();
        }
    }
}
