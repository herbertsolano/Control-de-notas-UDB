﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Panel_Materias : Form
    {
        public Docente_Panel_Materias()
        {
            InitializeComponent();
        }

        private void Docente_Panel_Materias_Load(object sender, EventArgs e)
        {
            string docente_file = "Docentes/"+Datos_docente.Inicio_Carnet2 + ".txt";
            StreamReader Leer_materias = new StreamReader(docente_file);
            List<string> materias = new List<string>();

            String element = "";
            
            while ((element = Leer_materias.ReadLine()) != null)
            {
                materias.Add(element);
            }
            Leer_materias.Close();

            Datos_docente.Materia1 = materias[0];
            Datos_docente.Materia2 = materias[1];
            Datos_docente.Materia3 = materias[2];
            lbl_Materia1.Text = Datos_docente.Materia1;
            lbl_Materia2.Text = Datos_docente.Materia2;    
            lbl_Materia3.Text = Datos_docente.Materia3;
        }

        private void lbl_Materia1_Click(object sender, EventArgs e)
        {
            Datos_Materias.Ingreso_Materia = Datos_docente.Materia1;
            Docente_Panel_Materia_Notas Ventanita = new Docente_Panel_Materia_Notas();
            Ventanita.Show();
        }

        private void lbl_Materia2_Click(object sender, EventArgs e)
        {
            Datos_Materias.Ingreso_Materia = Datos_docente.Materia2;
            Docente_Panel_Materia_Notas Ventanita = new Docente_Panel_Materia_Notas();
            Ventanita.Show();
        }

        private void lbl_Materia3_Click(object sender, EventArgs e)
        {
            Datos_Materias.Ingreso_Materia = Datos_docente.Materia3;
            Docente_Panel_Materia_Notas Ventanita = new Docente_Panel_Materia_Notas();
            Ventanita.Show();
        }
    }
}
