﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Form_Principal : Form
    {
        public Docente_Form_Principal()
        {
            InitializeComponent();

        }
        private void AbrirFormCum(object formcum)
        {
            if (this.panel_contenedor.Controls.Count > 0)
                this.panel_contenedor.Controls.RemoveAt(0);// Eliminacion de control

            Form AbrirCum = formcum as Form; //Creacion de formulario
            AbrirCum.TopLevel = false;
            AbrirCum.Dock = DockStyle.Fill;

            this.panel_contenedor.Controls.Add(AbrirCum);
            this.panel_contenedor.Tag = AbrirCum;
            AbrirCum.Show();

        }
        private void label1_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Panel_Principal());
        }

        private void lbl_Cerrar_Sesion_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
            Datos.Inicio_Carnet = "";
            Datos.Inicio_Apellido = "";
            Datos.Inicio_Nombre = "";
            Datos.Inicio_Email = "";
            Datos.Inicio_Carrera = "";
            Form_Autenticacion ir_autenticacion = new Form_Autenticacion();
            ir_autenticacion.Show();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Panel_Creditos());
        }

        private void Docente_Form_Principal_Load(object sender, EventArgs e)
        {
            AbrirFormCum(new Panel_Principal());
        }

        private void lbl_Informacion_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Docente_Panel_Informacion());
        }

        private void lbl_Registro_Click(object sender, EventArgs e)
        {
            AbrirFormCum(new Docente_Panel_Materias());
        }

        private void panel_contenedor_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
