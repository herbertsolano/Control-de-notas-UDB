﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_V1.Docente
{
    public class Datos_docente
    {
        static public string Inicio_Carnet2, Inicio_Nombre2, Inicio_Apellido2, Inicio_Email2, Inicio_Carrera2;
        static public string Materia1, Materia2, Materia3;

    }
}

