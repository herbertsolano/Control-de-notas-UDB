﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Docente
{
    public partial class Docente_Panel_Informacion : Form
    {
        public Docente_Panel_Informacion()
        {
            InitializeComponent();
        }

        private void Docente_Panel_Informacion_Load(object sender, EventArgs e)
        {
            lbl_Name.Text = "Nombre :   " + Datos_docente.Inicio_Nombre2;
            lbl_Lname.Text = "Apellido: " + Datos_docente.Inicio_Apellido2;
            lbl_Carnet.Text = "Carnet :   " + Datos_docente.Inicio_Carnet2;
            lbl_Email.Text = "Correo :   " + Datos_docente.Inicio_Email2;
        }
    }
}
