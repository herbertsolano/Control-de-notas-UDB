﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Alumnos
{
    public partial class Alumno_Panel_Informacion : Form
    {
        public Alumno_Panel_Informacion()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Alumno_Panel_Informacion_Load(object sender, EventArgs e)
        {
            lbl_Name.Text = "Nombre :   " +Datos.Inicio_Nombre;
            lbl_Lname.Text ="Apellidos: "+Datos.Inicio_Apellido;
           Lnl_Carnett.Text ="Carnet :   "+Datos.Inicio_Carnet;
            lbl_Email.Text ="Correo :   "+Datos.Inicio_Email;
          lbl_Carrera.Text ="Carrera :  "+Datos.Inicio_Carrera;
        }

    }
}
