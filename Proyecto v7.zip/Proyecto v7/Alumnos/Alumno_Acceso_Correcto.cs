﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Alumnos
{
    public partial class Alumno_Acceso_Correcto : Form
    {
        public Alumno_Acceso_Correcto()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            Alumno_Form_Principal ir_principal = new Alumno_Form_Principal();
            ir_principal.Show();
            this.Close();
            this.Hide();
        }

        
    }
}
