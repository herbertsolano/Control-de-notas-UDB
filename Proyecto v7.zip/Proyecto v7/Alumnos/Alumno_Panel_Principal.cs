﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1.Alumnos
{
    public partial class Alumno_Panel_Principal : Form
    {
        public Alumno_Panel_Principal()
        {
            InitializeComponent();
           
        }

        private void Alumno_Panel_Principal_Load(object sender, EventArgs e)
        {
            lbl_Frase_Bienvenida.Text = Datos.Inicio_Nombre + " " + Datos.Inicio_Apellido;
        }

    }
}
