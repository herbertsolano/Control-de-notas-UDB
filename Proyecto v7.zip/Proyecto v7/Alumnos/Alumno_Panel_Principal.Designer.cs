﻿namespace Proyecto_V1.Alumnos
{
    partial class Alumno_Panel_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_Frase_Bienvenida = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_V1.Properties.Resources.logotipo_full_color_letras_negras;
            this.pictureBox1.Location = new System.Drawing.Point(364, 263);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_Frase_Bienvenida
            // 
            this.lbl_Frase_Bienvenida.AutoSize = true;
            this.lbl_Frase_Bienvenida.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Frase_Bienvenida.Location = new System.Drawing.Point(478, 183);
            this.lbl_Frase_Bienvenida.Name = "lbl_Frase_Bienvenida";
            this.lbl_Frase_Bienvenida.Size = new System.Drawing.Size(74, 31);
            this.lbl_Frase_Bienvenida.TabIndex = 3;
            this.lbl_Frase_Bienvenida.Text = "Hola";
            this.lbl_Frase_Bienvenida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.Location = new System.Drawing.Point(318, 98);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(417, 31);
            this.lbl_nombre.TabIndex = 5;
            this.lbl_nombre.Text = "Bienvenido al Control de Notas";
            this.lbl_nombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Alumno_Panel_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 727);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.lbl_Frase_Bienvenida);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Alumno_Panel_Principal";
            this.Text = "Alumno_Panel_Principal";
            this.Load += new System.EventHandler(this.Alumno_Panel_Principal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_Frase_Bienvenida;
        private System.Windows.Forms.Label lbl_nombre;
    }
}