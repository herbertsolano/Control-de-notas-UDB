﻿namespace Proyecto_V1.Alumnos
{
    partial class Alumno_Form_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Informacion = new System.Windows.Forms.Label();
            this.lbl_Notas = new System.Windows.Forms.Label();
            this.lbl_Cerrar_Sesion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_contenedor = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbl_Informacion);
            this.panel1.Controls.Add(this.lbl_Notas);
            this.panel1.Controls.Add(this.lbl_Cerrar_Sesion);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 1106);
            this.panel1.TabIndex = 1;
            // 
            // lbl_Informacion
            // 
            this.lbl_Informacion.AutoSize = true;
            this.lbl_Informacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Informacion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Informacion.Location = new System.Drawing.Point(53, 436);
            this.lbl_Informacion.Name = "lbl_Informacion";
            this.lbl_Informacion.Size = new System.Drawing.Size(149, 58);
            this.lbl_Informacion.TabIndex = 7;
            this.lbl_Informacion.Text = "Informacion\r\npersonal";
            this.lbl_Informacion.Click += new System.EventHandler(this.lbl_Informacion_Click);
            // 
            // lbl_Notas
            // 
            this.lbl_Notas.AutoSize = true;
            this.lbl_Notas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Notas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Notas.Location = new System.Drawing.Point(91, 581);
            this.lbl_Notas.Name = "lbl_Notas";
            this.lbl_Notas.Size = new System.Drawing.Size(81, 29);
            this.lbl_Notas.TabIndex = 6;
            this.lbl_Notas.Text = "Notas";
            this.lbl_Notas.Click += new System.EventHandler(this.lbl_Notas_Click);
            // 
            // lbl_Cerrar_Sesion
            // 
            this.lbl_Cerrar_Sesion.AutoSize = true;
            this.lbl_Cerrar_Sesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cerrar_Sesion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Cerrar_Sesion.Location = new System.Drawing.Point(43, 681);
            this.lbl_Cerrar_Sesion.Name = "lbl_Cerrar_Sesion";
            this.lbl_Cerrar_Sesion.Size = new System.Drawing.Size(171, 29);
            this.lbl_Cerrar_Sesion.TabIndex = 5;
            this.lbl_Cerrar_Sesion.Text = "Cerrar sesion";
            this.lbl_Cerrar_Sesion.Click += new System.EventHandler(this.lbl_Cerrar_Sesion_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(75, 777);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Creditos";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_V1.Properties.Resources.WhatsApp_Image_2020_09_20_at_7_29_08_PM;
            this.pictureBox1.Location = new System.Drawing.Point(1, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(271, 246);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(72, 342);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Principal";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel_contenedor
            // 
            this.panel_contenedor.Location = new System.Drawing.Point(269, -1);
            this.panel_contenedor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_contenedor.Name = "panel_contenedor";
            this.panel_contenedor.Size = new System.Drawing.Size(1387, 896);
            this.panel_contenedor.TabIndex = 2;
            // 
            // Alumno_Form_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1657, 894);
            this.Controls.Add(this.panel_contenedor);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Alumno_Form_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alumno_Form_Principal";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Cerrar_Sesion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_contenedor;
        private System.Windows.Forms.Label lbl_Notas;
        private System.Windows.Forms.Label lbl_Informacion;
    }
}