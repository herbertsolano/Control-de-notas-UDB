﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_V1.Alumnos
{
    public partial class Alumno_Panel_Notas : Form
    {

        string f_alumno = "Estudiantes/" + Datos.Inicio_Carnet + ".txt";
        public Alumno_Panel_Notas()
        {
            InitializeComponent();
            Revisar_CUM();
        }

        private void Alumno_Panel_Notas_Load(object sender, EventArgs e)
        {
            Revisar_Notas();
        }

        public void Revisar_Notas()
        {

            StreamReader Lectura = new StreamReader(f_alumno);

            string[] columnnnames = Lectura.ReadLine().Split('-');
            DataTable dt = new DataTable();
            foreach (string c in columnnnames)
                dt.Columns.Add(c);
            string newline;
            while ((newline = Lectura.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] values = newline.Split('-');
                for (int i = 0; i < values.Length; i++)
                    dr[i] = values[i];
                dt.Rows.Add(dr);
            }
            Lectura.Close();
            dgrid_Notas.DataSource = dt;
            dgrid_Notas.AutoResizeColumns();


        }

        public void Revisar_CUM() 
        {
            StreamReader Lectura = new StreamReader(f_alumno);
            double suma_uv = 0;
            double suma_productos = 0;
            string lineas;

            while((lineas = Lectura.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = lineas.Split(delimitador);
                
                if(components[0]!= "Materia"&& components[0] != "Ciclo") 
                {
                    if(components[2] != "#")
                    {
                        suma_uv = Convert.ToDouble(components[1]) + suma_uv;
                        suma_productos = (Convert.ToDouble(components[1]) * Convert.ToDouble(components[2])) + suma_productos;
                    }
                    
                }
            }

            if (suma_productos != 0)
            {
                decimal decimalvalue =Convert.ToDecimal( suma_productos / suma_uv);

                decimalvalue = Math.Round(decimalvalue,2);
                lbl_CUM.Text = Convert.ToString(decimalvalue);
            }
            else
                lbl_CUM.Text = "0.00";
        }

        private void lbl_CUM_Click(object sender, EventArgs e)
        {

        }
    }
}
