﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_V1
{
    public class Datos
    {
        static public string Inicio_Carnet, Inicio_Nombre, Inicio_Apellido, Inicio_Email,Inicio_Carrera;
    }

    public class Registro 
    {
        static public string Nuevo_carnet;

        static public bool Ingreso_ok;

        static public Int16 n_ciclos;
    }

    public class Registro_new_student 
    {
        static public string Carnet, Apellido, Nombre, Correo;
    }
}
