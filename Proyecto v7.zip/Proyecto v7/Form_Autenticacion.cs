﻿using Proyecto_V1.Admin;
using Proyecto_V1.Alumnos;
using Proyecto_V1.Docente;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_V1
{
    public partial class Form_Autenticacion : Form
    {
        public Form_Autenticacion()
        {
            InitializeComponent();
        }


        List<string> listado_admin = new List<string>();
        List<string> Contra_admin = new List<string>();

        List<string> listado_docentes = new List<string>();
        List<string> Contra_docentes = new List<string>();
        List<string> Nombre_docentes = new List<string>();
        List<string> Apellido_docentes = new List<string>();
        List<string> Email_docentes = new List<string>();

        List<string> listado_alumnos = new List<string>();
        List<string> Contra_alumnos = new List<string>();
        List<string> Nombre_alumnos = new List<string>();
        List<string> Apellido_alumnos = new List<string>();
        List<string> Email_alumnos = new List<string>();
        List<string> Carrera_alumnos = new List<string>();

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    
        private void btt_ingresar_Click(object sender, EventArgs e)
        {
            int yes = 0;

            if (txt_user.Text == "Usuario" && txt_contra.Text == "Contraseña" || txt_user.Text == null && txt_contra.Text == "Contraseña" || txt_user.Text == "usuario" && txt_contra.Text == " ")
            {
                MessageBox.Show("Ingrese valores en los campos");
                return;
            }
            bool usuario;
            Form_Acceso_Incorrecto ir_acceso_incorrecto = new Form_Acceso_Incorrecto();
            usuario = listado_admin.Contains(txt_user.Text);
            if (usuario == true) //Revisar si admin esta en el listado
            {
                if (Contra_admin[listado_admin.IndexOf(txt_user.Text)] == txt_contra.Text)
                {
                    this.Hide();

                    Admin_Acceso_Correcto ir_acceso_correcto = new Admin_Acceso_Correcto();
                    ir_acceso_correcto.Show();
                    yes = yes + 1;
                    this.Close();
                    
                }
                else
                {
                    ir_acceso_incorrecto.Show();
                    return;
                }
                return;
            }
            
            usuario = listado_docentes.Contains(txt_user.Text);
            if (usuario == true) //Revisar si docente esta en el listado
            {
                int ubicacion = listado_docentes.IndexOf(txt_user.Text);
                if (Contra_docentes[ubicacion] == txt_contra.Text)
                {
                    this.Hide();
                    this.Close();
                    yes = yes + 1;

                    Datos_docente.Inicio_Carnet2 = listado_docentes[ubicacion];
                    Datos_docente.Inicio_Apellido2 = Apellido_docentes[ubicacion];
                    Datos_docente.Inicio_Nombre2 = Nombre_docentes[ubicacion];
                    Datos_docente.Inicio_Email2 = Email_docentes[ubicacion];

                    Docente_Acceso_Correcto ir_acceso_correcto_docente = new Docente_Acceso_Correcto();
                    ir_acceso_correcto_docente.Show();
                }
                else
                {

                    ir_acceso_incorrecto.Show();
                    return;
                }
                return;
            }

            usuario = listado_alumnos.Contains(txt_user.Text);
            if (usuario == true) //Revisar si alumno esta en el listado
            {
                int ubicacion = listado_alumnos.IndexOf(txt_user.Text);
                if (Contra_alumnos[ubicacion] == txt_contra.Text)
                {
                    this.Hide();
                    this.Close();
                    yes = yes + 1;

                    Datos.Inicio_Carnet = listado_alumnos[ubicacion];
                    Datos.Inicio_Apellido = Apellido_alumnos[ubicacion];
                    Datos.Inicio_Nombre = Nombre_alumnos[ubicacion];
                    Datos.Inicio_Email = Email_alumnos[ubicacion];
                    Datos.Inicio_Carrera = Carrera_alumnos[ubicacion];

                    Alumno_Acceso_Correcto ir_Acceso_Correcto_Alumno = new Alumno_Acceso_Correcto();
                    ir_Acceso_Correcto_Alumno.Show();
                }
                else
                {

                    ir_acceso_incorrecto.Show();
                    return;
                }
                return;
            }

            if (yes == 0) 
            {
                ir_acceso_incorrecto.Show();
            }

        }

        private void txt_user_Enter(object sender, EventArgs e)
        {
            if (txt_user.Text == "Usuario") 
            {
                txt_user.Text = "";
            }
        }//Eventos mouse en textbox usuario

        private void txt_user_Leave(object sender, EventArgs e)
        {
            if (txt_user.Text == "")
            {
                txt_user.Text = "Usuario";
            }
        }

        private void txt_contra_Enter(object sender, EventArgs e)
        {
            if(txt_contra.Text == "Contraseña") 
            {
                txt_contra.Text = "";
            }
        } // Eventos mouse en textboz contra

        private void txt_contra_Leave(object sender, EventArgs e)
        {
            if (txt_contra.Text == "")
            {
                txt_contra.Text = "Contraseña";
            }
        }

        private void Form_Autenticacion_Load(object sender, EventArgs e)
        {
            //Datos.Inicio_Carnet = "";

            StreamReader leer_admins = new StreamReader("User_Admin.txt");
            StreamReader leer_docentes = new StreamReader("User_Docentes.txt");
            StreamReader leer_alumnos = new StreamReader("User_Alumnos.txt");

            String element = "";

            while ((element = leer_admins.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = element.Split(delimitador);
                listado_admin.Add(components[0]);
                Contra_admin.Add(components[1]);
            }
            leer_admins.Close();

            while ((element = leer_docentes.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = element.Split(delimitador);
                listado_docentes.Add(components[0]);
                Contra_docentes.Add(components[1]);
                Apellido_docentes.Add(components[2]);
                Nombre_docentes.Add(components[3]);
                Email_docentes.Add(components[4]);

            }
            leer_docentes.Close();

            while ((element = leer_alumnos.ReadLine()) != null)
            {
                char[] delimitador = { '-' };
                string[] components = element.Split(delimitador);
                listado_alumnos.Add(components[0]);
                Contra_alumnos.Add(components[1]);
                Apellido_alumnos.Add(components[2]);
                Nombre_alumnos.Add(components[3]);
                Email_alumnos.Add(components[4]);
                Carrera_alumnos.Add(components[5]);
               
            }
            leer_alumnos.Close();
        }//Lee txt y los guarda en list
        

    }
}
